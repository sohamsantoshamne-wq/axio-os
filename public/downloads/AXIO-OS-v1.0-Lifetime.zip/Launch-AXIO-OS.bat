@echo off
title AXIO OS - Executive Consistency System
cd /d "%~dp0"
echo ========================================================
echo       AXIO OS: Daily Habits & Rhythm System
echo             Executive Consistency Engine
echo ========================================================
echo.
echo Starting AXIO OS in your default browser...
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0server.ps1"
pause

