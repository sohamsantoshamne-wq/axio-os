================================================================================
⚡ AXIO OS • Executive Daily Habits & Consistency System
================================================================================
Congratulations on purchasing AXIO OS Lifetime Access!

🚀 QUICK START (WINDOWS):
--------------------------------------------------------------------------------
1. Extract (unzip) all files in this folder to a permanent location (e.g. Desktop or Documents).
2. Double-click "Launch-AXIO-OS.bat".
3. AXIO OS will automatically open in your default browser at http://localhost:5174/!

🍏 MAC / LINUX USERS:
--------------------------------------------------------------------------------
1. Open Terminal in this folder.
2. Run: python3 -m http.server 5174
3. Open http://localhost:5174 in your browser.

🔒 PRIVACY & DATA:
--------------------------------------------------------------------------------
- AXIO OS stores 100% of your habit records locally on your machine.
- No accounts, no cloud tracking, no subscriptions ever.
- To backup or export your data anytime, use the "Export JSON Backup" button in Settings.

Need help or have questions?
Instagram: @axiohabits
Enjoy your unstoppable daily momentum!
================================================================================

